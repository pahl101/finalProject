//
//  SlangViewController.swift
//  NZSlang(FinalProject)
//
//  Created by Madison Pahl on 5/3/16.
//  Copyright © 2016 Madison Pahl. All rights reserved.
//

import UIKit

class SlangViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var slangWords : [SlangWords] = [Kiwi(),Jandals(),Dairy(),ChillyBin(),Wops(),Maccas(),Togs(),BonnetBoot(),Scull(),Buggered(),FizzyDrink(),HotChips(),Kai(),ChockaBlock(),Cuppa(),Jumper(),Angus(),Hungus(),KiaOra(),Tramping(),OpShops(),Waikikamukau(),Bro(),AllGood(),SweetAs(),Faaa(),As(),Hardout(),NotEven(),Ow(),Shot(),AFeed(),Reckon(),Mean(),Heaps(),PieceOfPiss(),TakingThePiss(),YeahNah(),ToTheDays(),HonestToWho(),Gizza(),Shout(),WhatASadGuy(),Aye(),Cuz(),Chur(),CantBeBothered(),Choice(),Suss(),Mint(),GapIt()]
    
    @IBOutlet weak var slangTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.slangTableView.dataSource = self
        self.slangTableView.delegate = self
        
        let cellNib = UINib(nibName: "SlangTableViewCell", bundle: nil)
        
        self.slangTableView.registerNib(cellNib, forCellReuseIdentifier: "slangCell")

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.slangWords.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let slang = self.slangWords[indexPath.row]
        
        
        let cell = tableView.dequeueReusableCellWithIdentifier("slangCell") as! SlangTableViewCell
        cell.textLabel!.text = slang.word
        
        
        return cell
    }
    
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        let navVC = storyboard!.instantiateViewControllerWithIdentifier("DetailView") as! UINavigationController
        let detailVC = navVC.viewControllers[0] as! SlangDetailViewController
        
        detailVC.slang = self.slangWords[indexPath.row]
        
        self.presentViewController(navVC, animated: true, completion: nil)
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        let cellChange = tableView.cellForRowAtIndexPath(indexPath)
        var wasViewed = slangWords[indexPath.row]
        
        wasViewed.viewed = !wasViewed.viewed
        
        
        if wasViewed.viewed {
            cellChange?.accessoryType = UITableViewCellAccessoryType.Checkmark
            
        }
        else {
            cellChange?.accessoryType = UITableViewCellAccessoryType.None
        }
        
        
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
