//
//  TestViewController.swift
//  NZSlang(FinalProject)
//
//  Created by Madison Pahl on 5/1/16.
//  Copyright © 2016 Madison Pahl. All rights reserved.
//

import UIKit

class TestViewController: UIViewController {
    
    var idx : Int = 0

    
    @IBOutlet weak var scrambledWordLabel: UILabel!
    @IBOutlet weak var inputTextField: UITextField!
    @IBOutlet weak var meaningTextView: UITextView!

    
    
    var slangWords : [SlangWords] = [Kiwi(),Jandals(),Dairy(),ChillyBin(),Wops(),Maccas(),Togs(),BonnetBoot(),Scull(),Buggered(),FizzyDrink(),HotChips(),Kai(),ChockaBlock(),Cuppa(),Jumper(),Angus(),Hungus(),KiaOra(),Tramping(),OpShops(),Waikikamukau(),Bro(),AllGood(),SweetAs(),Faaa(),As(),Hardout(),NotEven(),Ow(),Shot(),AFeed(),Reckon(),Mean(),Heaps(),PieceOfPiss(),TakingThePiss(),YeahNah(),ToTheDays(),HonestToWho(),Gizza(),Shout(),WhatASadGuy(),Aye(),Cuz(),Chur(),CantBeBothered(),Choice(),Suss(),Mint(),GapIt()]
    
    var slang : SlangWords!
    var theWord : String = ""
    var scrambledWord : String = ""
    var theMeaning : String = ""
    

    override func viewDidLoad() {
        slangWords.shuffle()

        
        theWord = slangWords[idx].word
        var charactersArray = Array(theWord.characters)
        charactersArray.shuffle()
        scrambledWord = String(charactersArray)
        theMeaning=slangWords[idx].meaning
        meaningTextView.text! = ""
        scrambledWordLabel.text! = scrambledWord.lowercaseString
        idx+=1
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func nextButton(sender: AnyObject) {
        if (idx >= slangWords.count)
        {
            inputTextField.text = ""
            theWord = slangWords[idx].word
            var charactersArray = Array(theWord.characters)
            charactersArray.shuffle()
            theMeaning=slangWords[idx].meaning
            scrambledWord = String(charactersArray)
            scrambledWordLabel.text = scrambledWord.lowercaseString
            idx+=1
        }
        else{
            slangWords.shuffle()
            idx = 0
            inputTextField.text = ""
            theWord = slangWords[idx].word
            var charactersArray = Array(theWord.characters)
            charactersArray.shuffle()
            theMeaning=slangWords[idx].meaning
            scrambledWord = String(charactersArray)
            scrambledWordLabel.text = scrambledWord.lowercaseString
            idx+=1
            
        }
        
        
    }

    @IBAction func goButton(sender: AnyObject) {
        if (inputTextField.text!.lowercaseString == theWord.lowercaseString)
        {
            let alert = UIAlertController(title: "CORRECT!", message: "Will display slang meaning now!", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "OK!", style: .Cancel, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
            meaningTextView.text = theMeaning
        }
            
        else{
            let alert = UIAlertController(title: "INCORRECT", message: "Please Try Again!", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "OK!", style: .Cancel, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
            meaningTextView.text = ""
        }
        
    }
    
    
    @IBAction func Back(sender: UIBarButtonItem) {
        dismissViewControllerAnimated(true, completion: nil)
    }
}


extension Array
{
    mutating func shuffle()
    {
        for _ in 0..<(count - 1)
        {
            sortInPlace { (_,_) in arc4random() < arc4random() }
        }
    }
}




