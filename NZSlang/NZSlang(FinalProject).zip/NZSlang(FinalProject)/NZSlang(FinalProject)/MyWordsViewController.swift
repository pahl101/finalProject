//
//  MyWordsViewController.swift
//  NZSlang(FinalProject)
//
//  Created by Madison Pahl on 5/3/16.
//  Copyright © 2016 Madison Pahl. All rights reserved.
//

import UIKit
import CoreData

class MyWordsViewController: UIViewController, UITableViewDataSource, NSFetchedResultsControllerDelegate, UITableViewDelegate {


    @IBOutlet weak var wordTableView: UITableView!
    var fetchedResultsController : NSFetchedResultsController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.wordTableView.dataSource = self
        self.wordTableView.delegate = self
        
        let wordFetch = NSFetchRequest(entityName: "Slang")
        let slangWordSort = NSSortDescriptor(key: "theWord", ascending: true)
        wordFetch.sortDescriptors = [slangWordSort]
        
        
        self.fetchedResultsController = NSFetchedResultsController(fetchRequest: wordFetch, managedObjectContext: AppDelegate.GetInstance().managedObjectContext, sectionNameKeyPath: nil, cacheName: "slangCache")
        
        try! self.fetchedResultsController.performFetch()
        self.fetchedResultsController.delegate = self

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.fetchedResultsController.fetchedObjects!.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let word = self.fetchedResultsController.fetchedObjects![indexPath.row] as! Slang
        
        let cell = UITableViewCell()
        cell.textLabel!.text = word.theWord
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let selectedWord = self.fetchedResultsController.fetchedObjects![indexPath.row] as! Slang
        
        let wordVC = self.storyboard!.instantiateViewControllerWithIdentifier("wordView") as! WordDetailViewController
        
        wordVC.editingWord = selectedWord
        
        self.navigationController?.pushViewController(wordVC, animated: true)
    }
    
    func controllerDidChangeContent(controller: NSFetchedResultsController) {
        self.wordTableView.reloadData()
    }
    
    


    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
